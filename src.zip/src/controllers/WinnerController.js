const Winner = require("../models/Winner")

exports.index = async (req,res) => {
    // await Winner.findAll({gr})
}

