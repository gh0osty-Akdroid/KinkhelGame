const Game = require("../../models/Game")
const responses = require('../../utils/responses')

exports.update = async (req, res) => {
    updateTime(req.body.time, req, res)
}

exports.destroy = async (req, res) => {
    updateTime(null, req, res)
}

const updateTime = async (time, req, res) => {
    let game = new Game()
    game = req.body.Game
    game.winner_announcement = time
    await game.save().then(v => responses.blankSuccess(res)).catch(err => responses.serverError(res, err))
}